
function fcns=normalcommon(p,prex,prez,betas,deltas)
p1=p(1);
p2=p(2);
p3=p(3);
x=prex;
z1=prez(1);
z2=prez(2);
z3=prez(3);
beta1=betas(1); beta2=betas(2); beta3=betas(3);
delta1=deltas(1); delta2=deltas(2); delta3=deltas(3);


fcns(1)=p1-normcdf(beta1*x+delta1*z1*(p2+p3)) ;
fcns(2)=p2-normcdf(beta2*x+delta2*z2*(p1+p3)) ;
fcns(3)=p3-normcdf(beta3*x+delta3*z3*(p1+p2)) ;

end