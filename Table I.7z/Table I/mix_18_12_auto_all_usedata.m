clear;
rng(2); 

GT=9000;

tiny=0.0001;
large=1-tiny;
tiny1=0.01;
large1=1-tiny1;

paras=[0.01 5 0.02 5.5 0.02 5.5 0.1 0.8 1.5 2.2 0.4 2.5 0.4 2.5 0.4]; 
                             
 
delta1A=paras(1);
delta1B=paras(2);
delta2A=paras(3);
delta2B=paras(4);
delta3A=paras(5);
delta3B=paras(6);
ZL=paras(7);
ZM=paras(8);
ZH=paras(9);
theta1A=paras(10);
theta1B=paras(11);
theta2A=paras(12);
theta2B=paras(13);
theta3A=paras(14);
theta3B=paras(15);
thetaA=[theta1A theta2A theta3A];
thetaB=[theta1B theta2B theta3B];
deltaA=[delta1A delta2A delta3A];
deltaB=[delta1B delta2B delta3B];

 
 
% all possible values of state variables 
allstate=[ZL ZL ZL delta1A delta2A delta3A theta1A theta2A theta3A; 
          ZL ZL ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZL ZL ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZL ZM delta1B delta2B delta3B theta1B theta2B theta3B;
           
           ZL ZL ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZL ZH delta1B delta2B delta3B theta1B theta2B theta3B;

          ZL ZM ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZM ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZL ZM ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZM ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZL ZM ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZM ZH delta1B delta2B delta3B theta1B theta2B theta3B;

        ZL ZH ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZH ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZL ZH ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZH ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZL ZH ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZH ZH delta1B delta2B delta3B theta1B theta2B theta3B;


          ZM ZL ZL delta1A delta2A delta3A theta1A theta2A theta3A; 
          ZM ZL ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZM ZL ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZL ZM delta1B delta2B delta3B theta1B theta2B theta3B;
           
           ZM ZL ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZL ZH delta1B delta2B delta3B theta1B theta2B theta3B;

          ZM ZM ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZM ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZM ZM ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZM ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZM ZM ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZM ZH delta1B delta2B delta3B theta1B theta2B theta3B;

        ZM ZH ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZH ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZM ZH ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZH ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZM ZH ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZH ZH delta1B delta2B delta3B theta1B theta2B theta3B;

          ];
  l_allstate=length(allstate(:,1));
      
  
  
  %all possible observed states 
  obstate=[ZL ZL ZL ; 
          
           ZL ZL ZM ;
          
           ZL  ZL ZH;

           ZL ZM ZL ;
          
           ZL ZM ZM ;
           ZL ZM ZH; 
           ZL ZH ZL;
           ZL ZH ZM;
           ZL ZH ZH;

          ZM ZL ZL ; 
          
          ZM ZL ZM ;
          
          ZM  ZL ZH;

          ZM ZM ZL ;
          
          ZM ZM ZM ;
          ZM ZM ZH; 
          ZM ZH ZL;
          ZM ZH ZM;
          ZM ZH ZH;

          ];
  l_obstate=length(obstate(:,1));
  
  

 storec1=1;
 storec2=[3 4];
 storec3=[5 6];
 storec4=[7 8];
 storec5=[9 10];
 storec6=[11 12];
 storec7=[13 14];
 storec8=[15 16];
 storec9=[17 18];
 storec10=[19 20];
 storec11=[21 22];
 storec12=[23 24];
 storec13=[25 26];
 storec14=[27 28];
 storec15=[29 30];
 storec16=[31 32];
 storec17=[33 34];
 storec18=[35 36];

 crr=1;
 c1=storec1;
 for i2=1:2
     c2=storec2(i2);
     for i3=1:2
         c3=storec3(i3);
         for i4=1:2
             c4=storec4(i4);
             for i5=1:2
                 c5=storec5(i5);
                 for i6=1:2
                     c6=storec6(i6);
                     for i7=1:2
                         c7=storec7(i7);
                         for i8=1:2
                             c8=storec8(i8);
                             for i9=1:2
                                c9=storec9(i9); 
                                for i10=1:2
                                    c10=storec10(i10);
                                    for i11=1:2
                                        c11=storec11(i11);
                                        for i12=1:2
                                            c12=storec12(i12);
                          C_space1(:,crr)=[c1 c2 c3 c4 c5 c6 c7 c8 c9 c10 c11 c12]';
                          crr=crr+1;
                                        end
                                    end
                                end
                             end
                                 end
           


end
end
end
end
end
end

                       
 

 
 
 
 
 
 crr=1;
                                 
                                
                                 
                                     
                                        
                                             for i13=1:2
                                                 c13=storec13(i13)
                                              for i14=1:2
                                                  c14=storec14(i14)
                                                for i15=1:2
                                                  c15=storec15(i15)
                                                   for i16=1:2
                                                      c16=storec16(i16)
                                                         for i17=1:2
                                                           c17=storec17(i17)
                                                             for i18=1:2
                                                                 c18=storec18(i18)
                                                                 
                          C_space2(:,crr)=[c13 c14 c15 c16 c17 c18]';
                          crr=crr+1;
           


end
end
end
end
end
                                     
                                 end
                                  
                                  
           load('data-newSt18-500');
           vecalpha=[0.005 0.01 0.015 0.025] ; 
%  veclambda=[-0.01 -0.03 -0.09 -0.27];
        
        %veclambda=[-0.01];
        veclambda=[-0.27 -0.09 -0.03 -0.01];
           lvecalpha=length(vecalpha);
           lveclambda=length(veclambda);
           iall=1;
          for ialpha=1:lvecalpha
              for ilambda=1:lveclambda
                                  pp=1; 
                                  alpha=vecalpha(ialpha);
                                  lambda=veclambda(ilambda);
thresh=pp*GT^(lambda);
                                   l_C1=length(C_space1(1,:));
                                        b1=l_C1;
 
 kp=ceil(l_C1*alpha);
                                  
                                  
                                  l_C2=length(C_space2(1,:));
 
 
 
 
 
 
 
 correct=0;
 
 
store_correct=zeros(1,100);
 
 

 
 
 
 
 include_correct=zeros(1,100);
 
for simu=1:allsims

D=storeD(:,:,simu);


    
    
    
    
    
   
    

%estimate ccps on two components
for s=1:l_obstate
  
    G=sum((D(:,4)==s));
     n1=sum((D(:,1)==1).*(D(:,4)==s));
     n0=sum((D(:,1)==0).*(D(:,4)==s));
     A1=1/G.*[n1;n0];
     %joint contingency table for player 1 and player 2
     n00= sum((D(:,1)==0).*(D(:,2)==0).*(D(:,4)==s));
     n11= sum((D(:,1)==1).*(D(:,2)==1).*(D(:,4)==s));
     n10= sum((D(:,1)==1).*(D(:,2)==0).*(D(:,4)==s));
     n01= sum((D(:,1)==0).*(D(:,2)==1).*(D(:,4)==s));
     A12=1/G.*[n11 n10;n01 n00];
     %joint contingency table for player 1 and player 2 holding player 3=1
     n001= sum((D(:,1)==0).*(D(:,2)==0).*(D(:,3)==1).*(D(:,4)==s));
     n111= sum((D(:,1)==1).*(D(:,2)==1).*(D(:,3)==1).*(D(:,4)==s));
     n101= sum((D(:,1)==1).*(D(:,2)==0).*(D(:,3)==1).*(D(:,4)==s));
     n011= sum((D(:,1)==0).*(D(:,2)==1).*(D(:,3)==1).*(D(:,4)==s));
     A12_1=1/G.*[n111 n101;n011 n001];
     
      
     %joint contingency table for player 1 and player 3
n00= sum((D(:,1)==0).*(D(:,3)==0).*(D(:,4)==s));
     n11= sum((D(:,1)==1).*(D(:,3)==1).*(D(:,4)==s));
     n10= sum((D(:,1)==1).*(D(:,3)==0).*(D(:,4)==s));
     n01= sum((D(:,1)==0).*(D(:,3)==1).*(D(:,4)==s));
     A13=1/G.*[n11 n10;n01 n00];
    



%[eigvct,eigvl]= eig(A1inv(A0));
[eigvct,eigvl]= eig(A12_1*inv(A12+tiny*eye(2)));
eigvct=real(eigvct);
sume=sum(eigvct);
nxiao1=[eigvct(:,1)/sume(1),eigvct(:,2)/sume(2)];
vWeight=inv(nxiao1+tiny*eye(2))*A1;
Weight=diag(vWeight);
nxiao2=A12'*inv(Weight'*nxiao1'+tiny*eye(2));
nxiao3=A13'*inv(Weight'*nxiao1'+tiny*eye(2));




estccp1=nxiao1(1,:)';
estccp2=nxiao2(1,:)';
estccp3=nxiao3(1,:)';

%trim estimated CCPs
%for player 1, its CCPs cannot get too close to 0 or 1 for F^-1 to be valid
%for player 2 and 3 CCPs outside [0,1] are trimed
estccp1=(estccp1>large1)*large1+(estccp1<=large1).*(estccp1>=tiny1).*estccp1+(estccp1<tiny1)*tiny1;
estccp2=(estccp2>=1)*large+(estccp2<1).*(estccp2>0).*estccp2+(estccp2<=0)*tiny;
estccp3=(estccp3>=1)*large+(estccp3<1).*(estccp3>0).*estccp3+(estccp3<=0)*tiny;



tempestccp(:,:,s)=[estccp1,estccp2,estccp3];



end

 


          
rr=1;
 for ss=1:l_obstate
             for kk=1:2
             estccp(rr,:)=tempestccp(kk,:,ss);
             rr=rr+1;
             end
 end
 

 %hold the order of the CCPs based on the sum across players
 %so that we can determine if each simulation selects the correct matching
 for zzl=1:l_obstate
            if sum(estccp(2*zzl-1,:)')<=sum(estccp(2*zzl,:)')
                pot=estccp(2*zzl,:);
                         estccp(2*zzl,:)=estccp(2*zzl-1,:);
                         estccp(2*zzl-1,:)=pot;
                         
            end
 end        
    
 estpibar=log(estccp(:,1)./(1-estccp(:,1)));
        
        estotherccp=estccp(:,2)+estccp(:,3);
        estGam=[allstate(:,1) estotherccp];
      
 %minimize on the first block
        
        tic 
        ilog=1;
        for ci=1:l_C1    
       c=C_space1(:,ci);
        obj1(ci)=(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:)+tiny*eye(2))*estGam(c,:)'*estpibar(c,1))'*(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:)+tiny*eye(2))*estGam(c,:)'*estpibar(c,1));  
       % if obj1(ci)<=thresh;
       %     C_space_estb1(:,ilog)=C_space1(:,ci);
       %     ilog=ilog+1;
       % end
        end
       % 
        
        %[minob1,minindc1]=min(obj1);
        %estc1=C_space1(:,minindc1);
        %estpi1=inv(estGam(estc1,:)'*estGam(estc1,:))*estGam(estc1,:)'*estpibar(estc1,1);
        
        [B,ind1] = mink(obj1,kp);
         quant_kp=B(kp);
         if quant_kp>thresh
            C_space_estb1=C_space1(:,ind1); 
         else
             tkp=kp;
            while quant_kp<=thresh
                [B,ind1] = mink(obj1,tkp);
                
                
         quant_kp=B(tkp); 
         %tkp=tkp+kp;
         tkp=tkp+1;
            end
            C_space_estb1=C_space1(:,ind1); 

         end
        l_C_estb1=length(C_space_estb1(1,:));
        
        %[B,ind1] = mink(obj1,kp);
        
        
     %{   
        %see if the upper half of the correct vector is included in C_space_estb1
        pre_include_correct=zeros(l_C_estb1,1);
        for ikp=1:l_C_estb1
           if (sum((C_space_estb1(:,ikp)==(1:2:2*b1-1)'))==b1)
            pre_include_correct(ikp)=1;
            %loc_correct=ikp;
           end 
           if sum(pre_include_correct)==1
               include_correct(1,simu)=1;
           end
        end
       %} 
        ci_all=1;
           for i1=1:l_C_estb1
               c1=C_space_estb1(:,i1);
               for i2=1:l_C2
               c2=C_space2(:,i2);   
               c=[c1;c2];
               C_space_all(:,ci_all)=c;
                       obj(ci_all)=(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:))*estGam(c,:)'*estpibar(c,1))'*(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:))*estGam(c,:)'*estpibar(c,1));  
                        ci_all=ci_all+1;
               end
           end
           
           %check if all elements in obj are equal
           store_obj_range(1,simu)=range(obj);

           
             
           [minob,minindc]=min(obj);
        estc=C_space_all(:,minindc); 
        
        
        
       %  finalXX=estGam(estc,:)'*estGam(estc,:);
    %           if rank(finalXX)<2
    %               finalXX=finalXX+0.01*eye(2);
    %           end
        
     % store_estpi(:,simu)=inv(finalXX)*estGam(estc,:)'*estpibar(estc,1);
        
        
        
        store_estc(:,simu)=estc;
        stime_2block(simu)=toc;
        
        if (sum((estc==(1:2:35)'))==18)
            store_correct(1,simu)=1;
            correct=correct+1;
        end
        
        %store_C_space_all(:,:,simu)=C_space_all;
        %store_obj(:,simu)=obj';
        
 obj=[];  
C_space_all=[];
C_space_estb1=[];
store_kp(simu)=l_C_estb1;
end
 time=mean(stime_2block);
   mkp=mean(store_kp);
   correctrate=correct/allsims;
    tab(iall,:)=[alpha lambda time correct];     
   iall=iall+1;
              end
          end