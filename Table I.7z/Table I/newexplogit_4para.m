
function fcns=newexplogit_4para(p,states)
p1=p(1);
p2=p(2);
p3=p(3);



z1=states(1,1);
z2=states(1,2);
z3=states(1,3);

del1=states(1,4);
del2=states(1,5);
del3=states(1,6);

th1=states(1,7);
th2=states(1,8);
th3=states(1,9);

fcns(1)= (1-1/(1+exp(th1*z1-del1*(p2+p3))))-p1;
fcns(2)= (1-1/(1+exp(th2*z2-del2*(p1+p3))))-p2;
fcns(3)= (1-1/(1+exp(th3*z3-del3*(p1+p2))))-p3;

end