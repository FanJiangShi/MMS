clear;


dev=-0.2; 

slurmid=getenv('SLURM_ARRAY_TASK_ID');

nsim=str2num(slurmid);
%nsim=1; 
block=10;
%rng(nsim); 
St=18;%=10+2*3+2
%storeC_space_2toend(1-14)
lblk=3;% the number of blocks in the middle
        %1-2-3-4-5
alls=St*2;
tiny=0.0001;
large=1-tiny;
tiny1=0.01;
large1=1-tiny1;
Delta=2;
% parameters

indfix=2;






















ns=500;
GT=ns*18;

paras=[0.01 5 0.02 5.5 0.02 5.5 0.1 0.8 1.5 2.2 0.4 2.5 0.4 2.5 0.4]; 
                             
 
delta1A=paras(1)+dev;
delta1AH0=paras(1);
delta1B=paras(2);
delta2A=paras(3);
delta2B=paras(4);
delta3A=paras(5);
delta3B=paras(6);
ZL=paras(7);
ZM=paras(8);
ZH=paras(9);
theta1A=paras(10);
theta1B=paras(11);
theta2A=paras(12);
theta2B=paras(13);
theta3A=paras(14);
theta3B=paras(15);
thetaA=[theta1A theta2A theta3A];
thetaB=[theta1B theta2B theta3B];
deltaA=[delta1A delta2A delta3A];
deltaB=[delta1B delta2B delta3B];

 
 
% all possible values of state variables 
allstate=[ZL ZL ZL delta1A delta2A delta3A theta1A theta2A theta3A; 
          ZL ZL ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZL ZL ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZL ZM delta1B delta2B delta3B theta1B theta2B theta3B;
           
           ZL ZL ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZL ZH delta1B delta2B delta3B theta1B theta2B theta3B;

          ZL ZM ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZM ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZL ZM ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZM ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZL ZM ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZM ZH delta1B delta2B delta3B theta1B theta2B theta3B;

        ZL ZH ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZH ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZL ZH ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZH ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZL ZH ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZH ZH delta1B delta2B delta3B theta1B theta2B theta3B;


          ZM ZL ZL delta1A delta2A delta3A theta1A theta2A theta3A; 
          ZM ZL ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZM ZL ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZL ZM delta1B delta2B delta3B theta1B theta2B theta3B;
           
           ZM ZL ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZL ZH delta1B delta2B delta3B theta1B theta2B theta3B;

          ZM ZM ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZM ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZM ZM ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZM ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZM ZM ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZM ZH delta1B delta2B delta3B theta1B theta2B theta3B;

        ZM ZH ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZH ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZM ZH ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZH ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZM ZH ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZH ZH delta1B delta2B delta3B theta1B theta2B theta3B;

          ];
  l_allstate=length(allstate(:,1));
      
  
  
  %all possible observed states 
  obstate=[ZL ZL ZL ; 
          
           ZL ZL ZM ;
          
           ZL  ZL ZH;

           ZL ZM ZL ;
          
           ZL ZM ZM ;
           ZL ZM ZH; 
           ZL ZH ZL;
           ZL ZH ZM;
           ZL ZH ZH;

          ZM ZL ZL ; 
          
          ZM ZL ZM ;
          
          ZM  ZL ZH;

          ZM ZM ZL ;
          
          ZM ZM ZM ;
          ZM ZM ZH; 
          ZM ZH ZL;
          ZM ZH ZM;
          ZM ZH ZH;

          ];
  l_obstate=length(obstate(:,1));
  
  %solve for equilibrium
 
 ccp=[]; ext=[]
 x0=[0.5 0.5 0.5];
 for i=1:l_allstate
     
  f=@(p)newexplogit_4para(p,allstate(i,:));
      
  [ccp(i,:), fval(i,:), exitflag(i)]=fsolve(f,x0);  
    
 end
 
otherccp=[];
otherccp(:,1)=ccp(:,2)+ccp(:,3);
otherccp(:,2)=ccp(:,1)+ccp(:,3);
otherccp(:,3)=ccp(:,1)+ccp(:,2);
 













%simulation control
BB=1000;


 
 
 storec1=1;
 storec2=[3 4];
 storec3=[5 6];
 storec4=[7 8];
 storec5=[9 10];
 storec6=[11 12];
 storec7=[13 14];
 storec8=[15 16];
 storec9=[17 18];
 storec10=[19 20];
 storec11=[21 22];
 storec12=[23 24];
 storec13=[25 26];
 storec14=[27 28];
 storec15=[29 30];
 storec16=[31 32];
 storec17=[33 34];
 storec18=[35 36];

 crr=1;
 c1=storec1;
 for i2=1:2
     c2=storec2(i2);
     for i3=1:2
         c3=storec3(i3);
         for i4=1:2
             c4=storec4(i4);
             for i5=1:2
                 c5=storec5(i5);
                 for i6=1:2
                     c6=storec6(i6);
                     for i7=1:2
                         c7=storec7(i7);
                         for i8=1:2
                             c8=storec8(i8);
                             for i9=1:2
                                c9=storec9(i9); 
                                for i10=1:2
                                    c10=storec10(i10);
                          C_space1(:,crr)=[c1 c2 c3 c4 c5 c6 c7 c8 c9 c10]';
                          crr=crr+1;
                                end
                             end
                                 end
           


end
end
end
end
end
end

                       
l_C1=length(C_space1(1,:));

 
 
 
 
 
 crr=1;
                                 
       
                                 
                                 
                                     for i11=1:2
                                        c11=storec11(i11)
                                        for i12=1:2
                                            c12=storec12(i12)
                                              
                                                        
                                                            
                                                                 
                          C_space2(:,crr)=[c11 c12]';
                          crr=crr+1;
           
                                                                 
                                                        
                                     end
                                     end
                         
       
                                     
 
 l_C2=length(C_space2(1,:));

 
 crr=1;
                            for i17=1:2
                                c17=storec17(i17);
                                 for i18=1:2
                                     c18=storec18(i18);
                                      C_space_last(:,crr)=[c17 c18]';
                          crr=crr+1;
                                 end
                            end
                           
 l_C_last=length(C_space_last(1,:));

storeC_space_2toend(:,:,1)=C_space2;
 %storel_C_3toend(1)=l_C2;
 for i=2:lblk
    storeC_space_2toend(:,:,i)= storeC_space_2toend(:,:,i-1)+2*Delta*ones(Delta,2^Delta);
      %storel_C_3toend(i)=length();

 end
 
 
 
 
 



         
                                     
                                     
                                     
                                     
                                     
                                     
                                     
                                     
                                     
                                     
                                     
 


















%true system for player 1
truepi=[theta1A;-1*delta1A]; 
   pp=1; 
   vecalpha=[0.005];
          %veclambda=[-0.01 -0.03 -0.09 -0.27];
              veclambda=[-0.01];
                 alpha1=vecalpha(1);
                lambda=veclambda(1);
                                  
    b1=10;                                 
thresh=pp*GT^(lambda);
                                   l_C1=length(C_space1(1,:));
 
 %kp
 kp1=ceil(l_C1*alpha1);
                                  
                                  
                                  l_C2=length(C_space2(1,:));

correct=0;







%nsim=1; 
rng(nsim);
%for simu=1:100 
 
for simu=(nsim-1)*block+1:nsim*block

 
    %D=storeD(:,:,simu);


    %generate data
eps=- log(ones(GT,3)./unifrnd(0,1,GT,3) - ones(GT,3));
indz=repmat([1:l_obstate]',GT/l_obstate,1);
    
  %store_eps(:,:,simu)=eps;  
    
    
    
    for g=1:GT 
 if indz(g)==2
                    indw=repmat(binornd(1,0.5),1,3);
        else
        indw=repmat(binornd(1,0.75-0.1/sum(obstate(indz(g),:))),1,3);
        end        
            D(g,:)=[(obstate(indz(g),:).*thetaA.*indw+obstate(indz(g),:).*thetaB.*(1-indw)-deltaA.*indw.*otherccp(2*indz(g)-1,:)-deltaB.*(1-indw).*otherccp(2*indz(g),:)-eps(g,:)>=0)+zeros(1,3),indz(g)];

    end
    
      
    
    



%##################################generate data
% generate private info
% generate index for observed state vector
%indz=randi([1 l_obstate],GT,1);

% generate index for observed state vector


%D(g,p,s) D each row is a observation, each column a player, each page an
%observed state    
  
    
%end

% Now need to estimate CCPs for each observed state vector
%Xiao estimate ccp1 on two components
for s=1:l_obstate
    G=sum((D(:,4)==s));
     n1=sum((D(:,1)==1).*(D(:,4)==s));
     n0=sum((D(:,1)==0).*(D(:,4)==s));
     A1=1/G.*[n1;n0];
     %joint contingency table for player 1 and player 2
     n00= sum((D(:,1)==0).*(D(:,2)==0).*(D(:,4)==s));
     n11= sum((D(:,1)==1).*(D(:,2)==1).*(D(:,4)==s));
     n10= sum((D(:,1)==1).*(D(:,2)==0).*(D(:,4)==s));
     n01= sum((D(:,1)==0).*(D(:,2)==1).*(D(:,4)==s));
     A12_0=1/G.*[n11 n10;n01 n00];
     %X12=A12_0;
     %joint contingency table for player 1 and player 2 holding player 3=1
     n001= sum((D(:,1)==0).*(D(:,2)==0).*(D(:,3)==1).*(D(:,4)==s));
     n111= sum((D(:,1)==1).*(D(:,2)==1).*(D(:,3)==1).*(D(:,4)==s));
     n101= sum((D(:,1)==1).*(D(:,2)==0).*(D(:,3)==1).*(D(:,4)==s));
     n011= sum((D(:,1)==0).*(D(:,2)==1).*(D(:,3)==1).*(D(:,4)==s));
     A12_1=1/G.*[n111 n101;n011 n001];
     
      
     %joint contingency table for player 1 and player 3
n00= sum((D(:,1)==0).*(D(:,3)==0).*(D(:,4)==s));
     n11= sum((D(:,1)==1).*(D(:,3)==1).*(D(:,4)==s));
     n10= sum((D(:,1)==1).*(D(:,3)==0).*(D(:,4)==s));
     n01= sum((D(:,1)==0).*(D(:,3)==1).*(D(:,4)==s));
     A13_0=1/G.*[n11 n10;n01 n00];
    
%end
%if rank(A12_0)<2
%A12_0=A12_0+0.01*eye(2);
%end    
%[eigvct,eigvl]= eig(A1inv(A0));
[eigvct,eigvl]= eig(A12_1*inv(A12_0+tiny*eye(2)));
sume=sum(eigvct);
nxiao1=real([eigvct(:,1)/sume(1),eigvct(:,2)/sume(2)]);
vWeight=inv(nxiao1+tiny*eye(2))*A1;
Weight=diag(vWeight);
nxiao2=A12_0'*inv(Weight'*nxiao1'+tiny*eye(2));
nxiao3=A13_0'*inv(Weight'*nxiao1'+tiny*eye(2));




nxiaoestccp1=nxiao1(1,:)';
nxiaoestccp2=nxiao2(1,:)';
nxiaoestccp3=nxiao3(1,:)';


nxiaoestccp1=(nxiaoestccp1>=large1)*large1+(nxiaoestccp1<large1).*(nxiaoestccp1>tiny1).*nxiaoestccp1+(nxiaoestccp1<=tiny1)*tiny1;
nxiaoestccp2=(nxiaoestccp2>=1)*large+(nxiaoestccp2<1).*(nxiaoestccp2>0).*nxiaoestccp2+(nxiaoestccp2<0)*tiny;
nxiaoestccp3=(nxiaoestccp3>=1)*large+(nxiaoestccp3<1).*(nxiaoestccp3>0).*nxiaoestccp3+(nxiaoestccp3<0)*tiny;



nxiaoestccp(:,:,s)=[nxiaoestccp1,nxiaoestccp2,nxiaoestccp3];



% the jacobian corresponding to each observed state is 2 by 15
%preJcb(:,:,s)=Gp(vp,truepi)*Pa(aaa)*Af(f);

%D=[];
end




          
rr=1;
 for ss=1:l_obstate
             for kk=1:2
             nxiaomestccp(rr,:)=nxiaoestccp(kk,:,ss);
             rr=rr+1;
             end
 end


 %first latent state generates larger CCPs
 for zzl=1:l_obstate
            if sum(nxiaomestccp(2*zzl-1,:)')<=sum(nxiaomestccp(2*zzl,:)')
                pot=nxiaomestccp(2*zzl,:);
                         nxiaomestccp(2*zzl,:)=nxiaomestccp(2*zzl-1,:);
                         nxiaomestccp(2*zzl-1,:)=pot;
                         
            end
        end        
        
        estpibar=log(nxiaomestccp(:,1)./(1-nxiaomestccp(:,1)));
        estotherccp=nxiaomestccp(:,2)+nxiaomestccp(:,3);
        estGam=[allstate(:,1) estotherccp];
        
        
        
        
        
        
        
        
        %bootstrap variance
         rowindD=[1:GT]';
        
        for b=1:BB
            bootind=datasample(rowindD,GT);
            bootD=D(bootind,:);
            
          %Xiao estimate ccp1 on two components
for s=1:l_obstate
    Gb=sum((bootD(:,4)==s));
     n1=sum((bootD(:,1)==1).*(bootD(:,4)==s));
     n0=sum((bootD(:,1)==0).*(bootD(:,4)==s));
     A1=1/Gb.*[n1;n0];
     %joint contingency table for player 1 and player 2
     n00= sum((bootD(:,1)==0).*(bootD(:,2)==0).*(bootD(:,4)==s));
     n11= sum((bootD(:,1)==1).*(bootD(:,2)==1).*(bootD(:,4)==s));
     n10= sum((bootD(:,1)==1).*(bootD(:,2)==0).*(bootD(:,4)==s));
     n01= sum((bootD(:,1)==0).*(bootD(:,2)==1).*(bootD(:,4)==s));
     A12_0=1/Gb.*[n11 n10;n01 n00];
     %X12=A12_0;
     %joint contingency table for player 1 and player 2 holding player 3=1
     n001= sum((bootD(:,1)==0).*(bootD(:,2)==0).*(bootD(:,3)==1).*(bootD(:,4)==s));
     n111= sum((bootD(:,1)==1).*(bootD(:,2)==1).*(bootD(:,3)==1).*(bootD(:,4)==s));
     n101= sum((bootD(:,1)==1).*(bootD(:,2)==0).*(bootD(:,3)==1).*(bootD(:,4)==s));
     n011= sum((bootD(:,1)==0).*(bootD(:,2)==1).*(bootD(:,3)==1).*(bootD(:,4)==s));
     A12_1=1/Gb.*[n111 n101;n011 n001];
     
      
     %joint contingency table for player 1 and player 3
n00= sum((bootD(:,1)==0).*(bootD(:,3)==0).*(bootD(:,4)==s));
     n11= sum((bootD(:,1)==1).*(bootD(:,3)==1).*(bootD(:,4)==s));
     n10= sum((bootD(:,1)==1).*(bootD(:,3)==0).*(bootD(:,4)==s));
     n01= sum((bootD(:,1)==0).*(bootD(:,3)==1).*(bootD(:,4)==s));
     A13_0=1/Gb.*[n11 n10;n01 n00];
    
%end
%if rank(A12_0)<2
%A12_0=A12_0+0.01*eye(2);
%end

%[eigvct,eigvl]= eig(A1inv(A0));
[eigvct,eigvl]= eig(A12_1*inv(A12_0+tiny*eye(2)));
sume=sum(eigvct);
nxiao1=real([eigvct(:,1)/sume(1),eigvct(:,2)/sume(2)]);
vWeight=inv(nxiao1+tiny*eye(2))*A1;
Weight=diag(vWeight);
nxiao2=A12_0'*inv(Weight'*nxiao1'+tiny*eye(2));
nxiao3=A13_0'*inv(Weight'*nxiao1'+tiny*eye(2));




nxiaoestccp1=nxiao1(1,:)';
nxiaoestccp2=nxiao2(1,:)';
nxiaoestccp3=nxiao3(1,:)';


nxiaoestccp1=(nxiaoestccp1>=large1)*large1+(nxiaoestccp1<large1).*(nxiaoestccp1>tiny1).*nxiaoestccp1+(nxiaoestccp1<=tiny1)*tiny1;
nxiaoestccp2=(nxiaoestccp2>=1)*large+(nxiaoestccp2<1).*(nxiaoestccp2>0).*nxiaoestccp2+(nxiaoestccp2<=0)*tiny;
nxiaoestccp3=(nxiaoestccp3>=1)*large+(nxiaoestccp3<1).*(nxiaoestccp3>0).*nxiaoestccp3+(nxiaoestccp3<=0)*tiny;



nxiaoestccp(:,:,s)=[nxiaoestccp1,nxiaoestccp2,nxiaoestccp3];



% the jacobian corresponding to each observed state is 2 by 15
%preJcb(:,:,s)=Gp(vp,truepi)*Pa(aaa)*Af(f);

%D=[];
end




          
rr=1;
 for ss=1:l_obstate
             for kk=1:2
             nxiaomestccp(rr,:)=nxiaoestccp(kk,:,ss);
             rr=rr+1;
             end
 end


 %first latent state generates larger CCPs
 for zzl=1:l_obstate
            if sum(nxiaomestccp(2*zzl-1,:)')<=sum(nxiaomestccp(2*zzl,:)')
                pot=nxiaomestccp(2*zzl,:);
                         nxiaomestccp(2*zzl,:)=nxiaomestccp(2*zzl-1,:);
                         nxiaomestccp(2*zzl-1,:)=pot;
                         
            end
        end        
        
        estpibarb=log(nxiaomestccp(:,1)./(1-nxiaomestccp(:,1)));
        estotherccpb=nxiaomestccp(:,2)+nxiaomestccp(:,3);
        estGamb=[allstate(:,1) estotherccpb];
        
    
        store_estpibarb(:,b)=estpibarb;
        store_estGamb(:,:,b)=estGamb;
            
           
            
        end
        
        
        
        
        
    
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
     % compute the test statistic   
    
       % step1. fix one parameter in the parameter vector
               testpi_fix=delta1AH0;
               indall=[1 2];
               indrm=setdiff(indall,indfix);
               deltan=estpibar-estGam(:,indfix)*testpi_fix;
               rmGam=estGam(:,indrm);
               
       % step 2. 
           % first get estpif for each c in C_space1
                
        tic 
        for ci=1:l_C1    
       c=C_space1(:,ci);
         estpif=inv(rmGam(c,:)'*rmGam(c,:)+tiny)*rmGam(c,:)'*deltan(c);
             %construct the restricted minimizer testpi
              testpi(indfix,1)=testpi_fix;
            testpi(indrm,1)=estpif;
       
       llc1=length(c);
      % XX=TVb(c,c);
      % if rank(XX)<llc1
      % XX=XX+tiny*eye(llc1);
      % end
        obj1(ci)=(estpibar(c,1)-estGam(c,:)*testpi)'*(estpibar(c,1)-estGam(c,:)*testpi);   
       % if obj1(ci)<=thresh;
       %     C_space_estb1(:,ilog)=C_space1(:,ci);
       %     ilog=ilog+1;
       % end
        end
       % 
        
        %[minob1,minindc1]=min(obj1);
        %estc1=C_space1(:,minindc1);
        %estpi1=inv(estGam(estc1,:)'*estGam(estc1,:))*estGam(estc1,:)'*estpibar(estc1,1);
        
        [B,ind1] = mink(obj1,kp1);
         quant_kp=B(kp1);
         if quant_kp>thresh
            C_space_estb=C_space1(:,ind1); 
         else
             tkp=kp1;
            while quant_kp<=thresh
                [B,ind1] = mink(obj1,tkp);
                
                
         quant_kp=B(tkp); 
         tkp=tkp+1;
            end
            C_space_estb=C_space1(:,ind1); 

         end
        l_C_estb=length(C_space_estb(1,:));
        
        %[B,ind1] = mink(obj1,kp);
        
        
        
        
        for ii=1:lblk
            C_spacenew=storeC_space_2toend(:,:,ii);

        ci_on=1;
           for i1=1:l_C_estb
               cold=C_space_estb(:,i1);
               for inew=1:l_C2
               cnew=C_spacenew(:,inew);   
               c=[cold;cnew];
               
                estpif=inv(rmGam(c,:)'*rmGam(c,:)+tiny)*rmGam(c,:)'*deltan(c);
             %construct the restricted minimizer testpi
              testpi(indfix,1)=testpi_fix;
            testpi(indrm,1)=estpif;
               
               
               
               C_space_on(:,ci_on)=c;
                       objon(ci_on)=(estpibar(c,1)-estGam(c,:)*testpi)'*(estpibar(c,1)-estGam(c,:)*testpi);   
                        ci_on=ci_on+1;
               end
           end
           l_Con=length(C_space_on(1,:));
        kp=ceil(l_Con*alpha1);   
           
          [B,ind1] = mink(objon,kp);
         quant_kp=B(kp);
         if quant_kp>thresh
            C_space_estbon=C_space_on(:,ind1); 
         else
             tkp=kp;
            while quant_kp<=thresh
                [B,ind1] = mink(objon,tkp);
                
                
         quant_kp=B(tkp); 
         %tkp=tkp+kp;
          tkp=tkp+1;
            end
            C_space_estbon=C_space_on(:,ind1); 

         end
        l_C_estbon=length(C_space_estbon(1,:));
        C_space_estb=[]; C_space_on=[]; objon=[];
        C_space_estb=C_space_estbon;C_space_estbon=[];
        l_C_estb=l_C_estbon;
        end
        
        
        
        
          ci_all=1;
           for iold=1:l_C_estb
               cold=C_space_estb(:,iold);
               for inew=1:l_C_last
               cnew=C_space_last(:,inew);   
               c=[cold;cnew];
               C_space_all(:,ci_all)=c;
               
 estpif=inv(rmGam(c,:)'*rmGam(c,:)+tiny)*rmGam(c,:)'*deltan(c);
                testpi(indfix,1)=testpi_fix;
            testpi(indrm,1)=estpif;
           for b=1:BB
               %tgnc for each c and each b, each element in store_tgnc_allc
               %only has rows selected by some c
               store_tgnc(:,b)=store_estpibarb(c,b)-store_estGamb(c,:,b)*testpi;
           end
           
           
               vbc=1/BB*(store_tgnc-mean(store_tgnc')')*(store_tgnc-mean(store_tgnc')')'+tiny*eye(l_obstate);
                estpif_opt=(rmGam(c,:)'*inv(vbc)*rmGam(c,:))^(-1)*rmGam(c,:)'*inv(vbc)*deltan(c);
        testpi(indrm)=estpif_opt;
        obj_all(ci_all)=(estpibar(c,1)-estGam(c,:)*testpi)'*inv(vbc)*(estpibar(c,1)-estGam(c,:)*testpi); 
           
           
           
           
                       ci_all=ci_all+1;                       
               end
           end  
           
                      l_C_all=length(C_space_all(1,:));
           
           
           
           
           
           
             
           [minob,minindc]=min(obj_all);
        
        
        
        
        
        
        
       

           
             
           
           
           
        
        %Tn from the minimum in C_space
       Tn_minboot(simu,1)=minob;
        
           
           
           
           
        estc=C_space_all(:,minindc); 
        
        
        
             
        
        
        
        
        store_estc(:,simu)=estc;
        stime_2block(simu)=toc;
        
        if (sum((estc==(1:2:35)'))==18)
            store_correct(1,simu)=1;
            correct=correct+1;
        end
        
        %store_C_space_all(:,:,simu)=C_space_all;
        %store_obj(:,simu)=obj';
  obj1=[];      
 obj_all=[];  
C_space_all=[];
C_space_estb=[];
store_kp(simu)=l_C_estb;
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
       
            
            
            
            
            
            
            
            
            
        
        
        
        
        
        
        
        
             
        
        
        
        
       
 
        
        
        
     
end
  sb=num2str(BB);
 strGT=num2str(GT/l_obstate);
 
     cv = chi2inv(0.95,l_obstate-1)

 
filename=strcat('ccm02subtest_',sb,'ns_',strGT,slurmid);
 save(filename,'Tn_minboot','cv','block');



