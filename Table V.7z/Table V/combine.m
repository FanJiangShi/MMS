clear;
narray=500;
for ii=1:narray
is=num2str(ii);
           %cbpowerp01subtest_ is m01
name=strcat('dlp005power500_1000ns_1000',is);
% name=strcat('subtest_1000ns_500',is);
%name=strcat('correct18test_B_4000ns_750',is);
load(name);

   allTn_boot(((ii-1)*block+1:ii*block)',1)=Tn_minboot(((ii-1)*block+1:ii*block)',1); 
    
  % storecorrect(ii)=correct;
    
    end
    
 %this cv for R2 only   
%cv = chi2inv(0.95,l_obstate-1)


sum((allTn_boot>cv))/(narray*block)
    
    correctrate=sum(storecorrect)/(narray*block)
    
    
    
    
    
    
    
    
    
    