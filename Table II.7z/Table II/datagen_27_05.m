clear;
ind=2;
rng(ind); 
ns=500;
GT=ns*27;
allsims=100;
St=27;
alls=54;


paras=[0.01 5 0.02 5.5 0.02 5.5 0.1 0.8 1.5 2.2 0.4 2.5 0.4 2.5 0.4]; 

delta1A=paras(1);
delta1B=paras(2);
delta2A=paras(3);
delta2B=paras(4);
delta3A=paras(5);
delta3B=paras(6);
ZL=paras(7);
ZM=paras(8);
ZH=paras(9);
theta1A=paras(10);
theta1B=paras(11);
theta2A=paras(12);
theta2B=paras(13);
theta3A=paras(14);
theta3B=paras(15);
thetaA=[theta1A theta2A theta3A];
thetaB=[theta1B theta2B theta3B];
deltaA=[delta1A delta2A delta3A];
deltaB=[delta1B delta2B delta3B];
 
 
% all possible values of state variables 
allstate=[ZL ZL ZL delta1A delta2A delta3A theta1A theta2A theta3A; 
          ZL ZL ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZL ZL ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZL ZM delta1B delta2B delta3B theta1B theta2B theta3B;
           
           ZL ZL ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZL ZH delta1B delta2B delta3B theta1B theta2B theta3B;

          ZL ZM ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZM ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZL ZM ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZM ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZL ZM ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZM ZH delta1B delta2B delta3B theta1B theta2B theta3B;

        ZL ZH ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZH ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZL ZH ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZH ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZL ZH ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZH ZH delta1B delta2B delta3B theta1B theta2B theta3B;


          ZM ZL ZL delta1A delta2A delta3A theta1A theta2A theta3A; 
          ZM ZL ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZM ZL ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZL ZM delta1B delta2B delta3B theta1B theta2B theta3B;
           
           ZM ZL ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZL ZH delta1B delta2B delta3B theta1B theta2B theta3B;

          ZM ZM ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZM ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZM ZM ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZM ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZM ZM ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZM ZH delta1B delta2B delta3B theta1B theta2B theta3B;

        ZM ZH ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZH ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZM ZH ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZH ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZM ZH ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZH ZH delta1B delta2B delta3B theta1B theta2B theta3B;


        ZH ZL ZL delta1A delta2A delta3A theta1A theta2A theta3A; 
          ZH ZL ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZH ZL ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZH ZL ZM delta1B delta2B delta3B theta1B theta2B theta3B;
           
           ZH ZL ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZH ZL ZH delta1B delta2B delta3B theta1B theta2B theta3B;

          ZH ZM ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZH ZM ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZH ZM ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZH ZM ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZH ZM ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZH ZM ZH delta1B delta2B delta3B theta1B theta2B theta3B;

        ZH ZH ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZH ZH ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZH ZH ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZH ZH ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZH ZH ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZH ZH ZH delta1B delta2B delta3B theta1B theta2B theta3B;

          ];
  l_allstate=length(allstate(:,1));
      
  
  
  %all possible observed states 
  obstate=[ZL ZL ZL ; 
          
          ZL ZL ZM ;
          
          ZL  ZL ZH;

          ZL ZM ZL ;
          
          ZL ZM ZM ;
          ZL ZM  ZH; 
          ZL ZH ZL;
          ZL ZH ZM;
          ZL ZH ZH;

ZM ZL ZL ; 
          
          ZM ZL ZM ;
          
          ZM  ZL ZH;

          ZM ZM ZL ;
          
          ZM ZM ZM ;
          ZM ZM  ZH; 
          ZM ZH ZL;
          ZM ZH ZM;
          ZM ZH ZH;
ZH ZL ZL ; 
          
          ZH ZL ZM ;
          
          ZH  ZL ZH;

          ZH ZM ZL ;
          
          ZH ZM ZM ;
          ZH ZM  ZH; 
          ZH ZH ZL;
          ZH ZH ZM;
          ZH ZH ZH;

          ];
  l_obstate=length(obstate(:,1));
  
  %solve for equilibrium
 
 ccp=[]; 
 x0=[0.5 0.5 0.5];
 for i=1:l_allstate
     
  f=@(p)newexplogit_4para(p,allstate(i,:));
      
  [ccp(i,:), fval(i,:), exitflag(i)]=fsolve(f,x0);  % in ccp, each column corresponds to a player 
    
 end
 
 % for each agent, compute sum of ccps of opponents
otherccp=[];
otherccp(:,1)=ccp(:,2)+ccp(:,3);
otherccp(:,2)=ccp(:,1)+ccp(:,3);
otherccp(:,3)=ccp(:,1)+ccp(:,2);
 
 

 
 

 
 
for simu=1:allsims





 
 

 
 
 
 
 
 
 

eps=- log(ones(GT,3)./unifrnd(0,1,GT,3) - ones(GT,3));
indz=repmat([1:27]',GT/27,1);



 
    
    
    
    
    
    for g=1:GT 
        
 if indz(g)==2
                    indw=repmat(binornd(1,0.5),1,3);
        else
        indw=repmat(binornd(1,0.75-0.1/sum(obstate(indz(g),:))),1,3);
        end        
            D(g,:)=[(obstate(indz(g),:).*thetaA.*indw+obstate(indz(g),:).*thetaB.*(1-indw)-deltaA.*indw.*otherccp(2*indz(g)-1,:)-deltaB.*(1-indw).*otherccp(2*indz(g),:)-eps(g,:)>=0)+zeros(1,3),indz(g)];

    end
    
    
storeD(:,:,simu)=D;
end
      
       name=strcat('data-newSt27-',num2str(ns));
      save(name)
      