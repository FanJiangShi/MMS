clear;
%rng(2); 
St=27;%=10+3+3+3+3+3+2
        %1 2 3 4 5  6 7
alls=54;
tiny=0.0001;
large=1-tiny;
tiny1=0.01;
large1=1-tiny1;
Delta=3;
paras=[0.01 5 0.02 5.5 0.02 5.5 0.1 0.8 1.5 2.2 0.4 2.5 0.4 2.5 0.4]; 

delta1A=paras(1);
delta1B=paras(2);
delta2A=paras(3);
delta2B=paras(4);
delta3A=paras(5);
delta3B=paras(6);
ZL=paras(7);
ZM=paras(8);
ZH=paras(9);
theta1A=paras(10);
theta1B=paras(11);
theta2A=paras(12);
theta2B=paras(13);
theta3A=paras(14);
theta3B=paras(15);
thetaA=[theta1A theta2A theta3A];
thetaB=[theta1B theta2B theta3B];
deltaA=[delta1A delta2A delta3A];
deltaB=[delta1B delta2B delta3B];
 
 
% all possible values of state variables 
allstate=[ZL ZL ZL delta1A delta2A delta3A theta1A theta2A theta3A; 
          ZL ZL ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZL ZL ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZL ZM delta1B delta2B delta3B theta1B theta2B theta3B;
           
           ZL ZL ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZL ZH delta1B delta2B delta3B theta1B theta2B theta3B;

          ZL ZM ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZM ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZL ZM ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZM ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZL ZM ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZM ZH delta1B delta2B delta3B theta1B theta2B theta3B;

        ZL ZH ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZH ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZL ZH ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZH ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZL ZH ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZL ZH ZH delta1B delta2B delta3B theta1B theta2B theta3B;


          ZM ZL ZL delta1A delta2A delta3A theta1A theta2A theta3A; 
          ZM ZL ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZM ZL ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZL ZM delta1B delta2B delta3B theta1B theta2B theta3B;
           
           ZM ZL ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZL ZH delta1B delta2B delta3B theta1B theta2B theta3B;

          ZM ZM ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZM ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZM ZM ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZM ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZM ZM ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZM ZH delta1B delta2B delta3B theta1B theta2B theta3B;

        ZM ZH ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZH ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZM ZH ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZH ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZM ZH ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZM ZH ZH delta1B delta2B delta3B theta1B theta2B theta3B;


        ZH ZL ZL delta1A delta2A delta3A theta1A theta2A theta3A; 
          ZH ZL ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZH ZL ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZH ZL ZM delta1B delta2B delta3B theta1B theta2B theta3B;
           
           ZH ZL ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZH ZL ZH delta1B delta2B delta3B theta1B theta2B theta3B;

          ZH ZM ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZH ZM ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZH ZM ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZH ZM ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZH ZM ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZH ZM ZH delta1B delta2B delta3B theta1B theta2B theta3B;

        ZH ZH ZL delta1A delta2A delta3A theta1A theta2A theta3A;
          ZH ZH ZL delta1B delta2B delta3B theta1B theta2B theta3B;
          ZH ZH ZM delta1A delta2A delta3A theta1A theta2A theta3A;
          ZH ZH ZM delta1B delta2B delta3B theta1B theta2B theta3B;

          ZH ZH ZH delta1A delta2A delta3A theta1A theta2A theta3A;
          ZH ZH ZH delta1B delta2B delta3B theta1B theta2B theta3B;

          ];
  l_allstate=length(allstate(:,1));
      
  
  
  %all possible observed states 
  obstate=[ZL ZL ZL ; 
          
          ZL ZL ZM ;
          
          ZL  ZL ZH;

          ZL ZM ZL ;
          
          ZL ZM ZM ;
          ZL ZM  ZH; 
          ZL ZH ZL;
          ZL ZH ZM;
          ZL ZH ZH;

ZM ZL ZL ; 
          
          ZM ZL ZM ;
          
          ZM  ZL ZH;

          ZM ZM ZL ;
          
          ZM ZM ZM ;
          ZM ZM  ZH; 
          ZM ZH ZL;
          ZM ZH ZM;
          ZM ZH ZH;
ZH ZL ZL ; 
          
          ZH ZL ZM ;
          
          ZH  ZL ZH;

          ZH ZM ZL ;
          
          ZH ZM ZM ;
          ZH ZM  ZH; 
          ZH ZH ZL;
          ZH ZH ZM;
          ZH ZH ZH;

          ];
  l_obstate=length(obstate(:,1));
  
  %solve for equilibrium
 
 ccp=[]; 
 x0=[0.5 0.5 0.5];
 for i=1:l_allstate
     
  f=@(p)newexplogit_4para(p,allstate(i,:));
      
  [ccp(i,:), fval(i,:), exitflag(i)]=fsolve(f,x0);  % in ccp, each column corresponds to a player 
    
 end
 
 % for each agent, compute sum of ccps of opponents
otherccp=[];
otherccp(:,1)=ccp(:,2)+ccp(:,3);
otherccp(:,2)=ccp(:,1)+ccp(:,3);
otherccp(:,3)=ccp(:,1)+ccp(:,2);
 
 

 correct=0;
 
  storec1=1;
 storec2=[3 4];
 storec3=[5 6];
 storec4=[7 8];
 storec5=[9 10];
 storec6=[11 12];
 storec7=[13 14];
 storec8=[15 16];
 storec9=[17 18];
 storec10=[19 20];
 storec11=[21 22];
 storec12=[23 24];
 storec13=[25 26];
 storec14=[27 28];
 storec15=[29 30];
 storec16=[31 32];
 storec17=[33 34];
 storec18=[35 36];
storec19=[37 38];
storec20=[39 40];
storec21=[41 42];
storec22=[43 44];
storec23=[45 46];
storec24=[47 48];
storec25=[49 50];
storec26=[51 52];
storec27=[53 54];
 
 
 
% load('storeC');
 
% l_C=length(C_space(1,:));


c1=1;crr=1;
for i2=1:2
     c2=storec2(i2);
     for i3=1:2
         c3=storec3(i3);
         for i4=1:2
             c4=storec4(i4);
             for i5=1:2
                 c5=storec5(i5);
                 for i6=1:2
                     c6=storec6(i6);
                     for i7=1:2
                         c7=storec7(i7);
                         for i8=1:2
                             c8=storec8(i8);
                              for i9=1:2
                                 c9=storec9(i9);
                                 for i10=1:2
                                   c10=storec10(i10);
                                                                 
                          C_space1(:,crr)=[c1 c2 c3 c4 c5 c6 c7 c8 c9 c10]';
                          crr=crr+1;
                                 end
           
end
end
end
end
end
end
end
end

                       
 
 l_C1=length(C_space1(1,:));
 
 
 
 
 
 
 
 
 crr=1;
                                 
                                 
                                     for i11=1:2
                                        c11=storec11(i11)
                                         for i12=1:2
                                             c12=storec12(i12)
                                             for i13=1:2
                                                 c13=storec13(i13)
                                              
                                                   
                                                        
                                                            
                                                                 
                          C_space2(:,crr)=[c11 c12 c13]';
                          crr=crr+1;
           
                                                                 


end
end
end


 
 l_C2=length(C_space2(1,:));



 
  C_space3=C_space2+2*Delta*ones(Delta,2^Delta);
l_C3=length(C_space3(1,:));
 
  C_space4=C_space3+2*Delta*ones(Delta,2^Delta);
l_C4=length(C_space4(1,:));
 
 C_space5=C_space4+2*Delta*ones(Delta,2^Delta);
l_C5=length(C_space5(1,:));
 
  C_space6=C_space5+2*Delta*ones(Delta,2^Delta);
l_C6=length(C_space6(1,:));
 
 
 crr=1;
                        
                            for i26=1:2
                         
                           c26=storec26(i26);
                                 for i27=1:2
                                     c27=storec27(i27);
                                      C_space7(:,crr)=[c26  c27]';
                          crr=crr+1;
                                 end
                             
                            end
                        
 
 l_C7=length(C_space7(1,:));
 

 load('data-newSt27-500')
 
                            
           % b1=14;                      
        vecalpha1=[0.005 0.01 ] ; 
       %  veclambda=[-0.01 -0.03 -0.09 -0.27];
         veclambda=[  -0.03 -0.01];
       %vecalpha1=[0.005];
         %veclambda=[-0.01];
         lvecalpha=length(vecalpha1);
           lveclambda=length(veclambda);
           iall=1;
          for ialpha=1:lvecalpha
              for ilambda=1:lveclambda
                                  pp=1; 
                                  alpha1=vecalpha1(ialpha);
                                  lambda=veclambda(ilambda);
thresh=pp*GT^(lambda);
 
 
 kp1=ceil(l_C1*alpha1);
 alpha=2^(-Delta);
                  %alpha=alpha;                
                                  
                                  l_C2=length(C_space2(1,:));
 
 
 
 
 
 
 
 
 
 
store_correct=zeros(1,100);
 
 

 
 
 
 
 include_correct=zeros(1,100);
 
 
 
 
 
 correct=0;
 

 
for simu=1:allsims

D=storeD(:,:,simu);




    

for s=1:l_obstate
    G=sum((D(:,4)==s));
     n1=sum((D(:,1)==1).*(D(:,4)==s));
     n0=sum((D(:,1)==0).*(D(:,4)==s));
     A1=1/G.*[n1;n0];
     %joint contingency table for player 1 and player 2
     n00= sum((D(:,1)==0).*(D(:,2)==0).*(D(:,4)==s));
     n11= sum((D(:,1)==1).*(D(:,2)==1).*(D(:,4)==s));
     n10= sum((D(:,1)==1).*(D(:,2)==0).*(D(:,4)==s));
     n01= sum((D(:,1)==0).*(D(:,2)==1).*(D(:,4)==s));
     A12_0=1/G.*[n11 n10;n01 n00];
     %X12=A12_0;
     %joint contingency table for player 1 and player 2 holding player 3=1
     n001= sum((D(:,1)==0).*(D(:,2)==0).*(D(:,3)==1).*(D(:,4)==s));
     n111= sum((D(:,1)==1).*(D(:,2)==1).*(D(:,3)==1).*(D(:,4)==s));
     n101= sum((D(:,1)==1).*(D(:,2)==0).*(D(:,3)==1).*(D(:,4)==s));
     n011= sum((D(:,1)==0).*(D(:,2)==1).*(D(:,3)==1).*(D(:,4)==s));
     A12_1=1/G.*[n111 n101;n011 n001];
    
      
     %joint contingency table for player 1 and player 3
n00= sum((D(:,1)==0).*(D(:,3)==0).*(D(:,4)==s));
     n11= sum((D(:,1)==1).*(D(:,3)==1).*(D(:,4)==s));
     n10= sum((D(:,1)==1).*(D(:,3)==0).*(D(:,4)==s));
     n01= sum((D(:,1)==0).*(D(:,3)==1).*(D(:,4)==s));
     A13_0=1/G.*[n11 n10;n01 n00];
  %if rank(A12_0)<2
  %   A12_0=A12_0+0.01*eye(2); 
  %end

[eigvct,eigvl]= eig(A12_1*inv(A12_0+tiny*eye(2)));
eigvct=real(eigvct);
sume=sum(eigvct);
nxiao1=[eigvct(:,1)/sume(1),eigvct(:,2)/sume(2)];
%if rank(nxiao1)<2
%     nxiao1=nxiao1+0.01*eye(2); 
%  end

vWeight=inv(nxiao1+tiny*eye(2))*A1;
Weight=diag(vWeight);
nxiao2=A12_0'*inv(Weight'*nxiao1'+tiny*eye(2));
nxiao3=A13_0'*inv(Weight'*nxiao1'+tiny*eye(2));
 
 
 
 
nxiaoestccp1=nxiao1(1,:)';
nxiaoestccp2=nxiao2(1,:)';
nxiaoestccp3=nxiao3(1,:)';
 
 
%nxiaoestccp1=(nxiaoestccp1>=1)*large+(nxiaoestccp1<1).*(nxiaoestccp1>0).*nxiaoestccp1+(nxiaoestccp1<=0)*tiny;
nxiaoestccp1=(nxiaoestccp1>large1)*large1+(nxiaoestccp1<large1).*(nxiaoestccp1>tiny1).*nxiaoestccp1+(nxiaoestccp1<tiny1)*tiny1;

nxiaoestccp2=(nxiaoestccp2>=1)*large+(nxiaoestccp2<1).*(nxiaoestccp2>0).*nxiaoestccp2+(nxiaoestccp2<=0)*tiny;
nxiaoestccp3=(nxiaoestccp3>=1)*large+(nxiaoestccp3<1).*(nxiaoestccp3>0).*nxiaoestccp3+(nxiaoestccp3<=0)*tiny;
 
 
 
nxiaoestccp(:,:,s)=[nxiaoestccp1,nxiaoestccp2,nxiaoestccp3];
 
 


end
 
 
          
rr=1;
 for ss=1:l_obstate
             for kk=1:2
             nxiaomestccp(rr,:)=nxiaoestccp(kk,:,ss);
             rr=rr+1;
             end
 end
 
 for zzl=1:l_obstate
            if sum(nxiaomestccp(2*zzl-1,:)')<=sum(nxiaomestccp(2*zzl,:)')
                pot=nxiaomestccp(2*zzl,:);
                         nxiaomestccp(2*zzl,:)=nxiaomestccp(2*zzl-1,:);
                         nxiaomestccp(2*zzl-1,:)=pot;
                         
            end
        end        
        
        estpibar=log(nxiaomestccp(:,1)./(1-nxiaomestccp(:,1)));
        estotherccp=nxiaomestccp(:,2)+nxiaomestccp(:,3);
        estGam=[allstate(:,1) estotherccp];
        
        
   
%minimize on the first block
        
        tic
        for ci=1:l_C1    
       c=C_space1(:,ci);
        obj1(ci)=(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:)+tiny*eye(2))*estGam(c,:)'*estpibar(c,1))'*(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:)+tiny*eye(2))*estGam(c,:)'*estpibar(c,1));  
    end
    
        
        [B,ind1] = mink(obj1,kp1);
         quant_kp=B(kp1);
         if quant_kp>thresh
            C_space_estb1=C_space1(:,ind1); 
         else
             tkp=kp1;
            while quant_kp<=thresh
                [B,ind1] = mink(obj1,tkp);
                
                
         quant_kp=B(tkp); 
         %tkp=tkp+kp;
          tkp=tkp+1;
            end
            C_space_estb1=C_space1(:,ind1); 

         end
        l_C_estb1=length(C_space_estb1(1,:));
        
        
        
        
        
        ci_12=1;
           for i1=1:l_C_estb1
               c1=C_space_estb1(:,i1);
               for i2=1:l_C2
               c2=C_space2(:,i2);   
               c=[c1;c2];
               C_space_12(:,ci_12)=c;
                       obj12(ci_12)=(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:)+tiny*eye(2))*estGam(c,:)'*estpibar(c,1))'*(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:)+tiny*eye(2))*estGam(c,:)'*estpibar(c,1));  
                        ci_12=ci_12+1;
               end
           end
           l_C12=length(C_space_12(1,:));
        kp=ceil(l_C12*alpha);   
           
          [B,ind1] = mink(obj12,kp);
         quant_kp=B(kp);
         if quant_kp>thresh
            C_space_estb12=C_space_12(:,ind1); 
         else
             tkp=kp;
            while quant_kp<=thresh
                [B,ind1] = mink(obj12,tkp);
                
                
         quant_kp=B(tkp); 
         %tkp=tkp+kp;
          tkp=tkp+1;
            end
            C_space_estb12=C_space_12(:,ind1); 

         end
        l_C_estb12=length(C_space_estb12(1,:));

           
        
        
        
        
           ci_123=1;
           for i12=1:l_C_estb12
               c12=C_space_estb12(:,i12);
               for i3=1:l_C3
               c3=C_space3(:,i3);   
               c=[c12;c3];
               C_space_123(:,ci_123)=c;
               
               
                       obj123(ci_123)=(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:)+tiny*eye(2))*estGam(c,:)'*estpibar(c,1))'*(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:)+tiny*eye(2))*estGam(c,:)'*estpibar(c,1));  
                        ci_123=ci_123+1;
               end
           end
           
             l_C123=length(C_space_123(1,:));
        kp=ceil(l_C123*alpha);  
           
             [B,ind1] = mink(obj123,kp);
         quant_kp=B(kp);
         if quant_kp>thresh
            C_space_estb123=C_space_123(:,ind1); 
         else
             tkp=kp;
            while quant_kp<=thresh
                [B,ind1] = mink(obj123,tkp);
                
                
         quant_kp=B(tkp); 
         %tkp=tkp+kp;
          tkp=tkp+1;
            end
            C_space_estb123=C_space_123(:,ind1); 

         end
        l_C_estb123=length(C_space_estb123(1,:));
           
           
           
           
        
        
        
        
        
        
        
           ci_1234=1;
           for i123=1:l_C_estb123
               c123=C_space_estb123(:,i123);
               for i4=1:l_C4
               c4=C_space4(:,i4);   
               c=[c123;c4];
               C_space_1234(:,ci_1234)=c;
               
               
                       obj1234(ci_1234)=(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:)+tiny*eye(2))*estGam(c,:)'*estpibar(c,1))'*(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:)+tiny*eye(2))*estGam(c,:)'*estpibar(c,1));  
                        ci_1234=ci_1234+1;
               end
           end
           
             l_C1234=length(C_space_1234(1,:));
        kp=ceil(l_C1234*alpha);  
           
             [B,ind1] = mink(obj1234,kp);
         quant_kp=B(kp);
         if quant_kp>thresh
            C_space_estb1234=C_space_1234(:,ind1); 
         else
             tkp=kp;
            while quant_kp<=thresh
                [B,ind1] = mink(obj1234,tkp);
                
                
         quant_kp=B(tkp); 
         %tkp=tkp+kp;
          tkp=tkp+1;
            end
            C_space_estb1234=C_space_1234(:,ind1); 

         end
        l_C_estb1234=length(C_space_estb1234(1,:));
        
        
        
        
        
        
        
        
        
        
         ci_12345=1;
           for i1234=1:l_C_estb1234
               c1234=C_space_estb1234(:,i1234);
               for i5=1:l_C5
               c5=C_space5(:,i5);   
               c=[c1234;c5];
               C_space_12345(:,ci_12345)=c;
               
               
                       obj12345(ci_12345)=(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:)+tiny*eye(2))*estGam(c,:)'*estpibar(c,1))'*(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:)+tiny*eye(2))*estGam(c,:)'*estpibar(c,1));  
                        ci_12345=ci_12345+1;
               end
           end
           
             l_C12345=length(C_space_12345(1,:));
        kp=ceil(l_C12345*alpha);  
           
             [B,ind1] = mink(obj12345,kp);
         quant_kp=B(kp);
         if quant_kp>thresh
            C_space_estb12345=C_space_12345(:,ind1); 
         else
             tkp=kp;
            while quant_kp<=thresh
                [B,ind1] = mink(obj12345,tkp);
                
                
         quant_kp=B(tkp); 
         %tkp=tkp+kp;
          tkp=tkp+1;
            end
            C_space_estb12345=C_space_12345(:,ind1); 

         end
        l_C_estb12345=length(C_space_estb12345(1,:));
        
        
        
        
        
        
        
        
        
        
         ci_123456=1;
           for i12345=1:l_C_estb12345
               c12345=C_space_estb12345(:,i12345);
               for i6=1:l_C6
               c6=C_space6(:,i6);   
               c=[c12345;c6];
               C_space_123456(:,ci_123456)=c;
               
               
                       obj123456(ci_123456)=(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:)+tiny*eye(2))*estGam(c,:)'*estpibar(c,1))'*(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:)+tiny*eye(2))*estGam(c,:)'*estpibar(c,1));  
                        ci_123456=ci_123456+1;
               end
           end
           
             l_C123456=length(C_space_123456(1,:));
        kp=ceil(l_C123456*alpha);  
           
             [B,ind1] = mink(obj123456,kp);
         quant_kp=B(kp);
         if quant_kp>thresh
            C_space_estb123456=C_space_123456(:,ind1); 
         else
             tkp=kp;
            while quant_kp<=thresh
                [B,ind1] = mink(obj123456,tkp);
                
                
         quant_kp=B(tkp); 
         %tkp=tkp+kp;
          tkp=tkp+1;
            end
            C_space_estb123456=C_space_123456(:,ind1); 

         end
        l_C_estb123456=length(C_space_estb123456(1,:));
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
           ci_all=1;
           for i123456=1:l_C_estb123456
               c123456=C_space_estb123456(:,i123456);
               for i7=1:l_C7
               c7=C_space7(:,i7);   
               c=[c123456;c7];
               C_space_all(:,ci_all)=c;
               
               
                       obj_all(ci_all)=(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:)+tiny*eye(2))*estGam(c,:)'*estpibar(c,1))'*(estpibar(c,1)-estGam(c,:)*inv(estGam(c,:)'*estGam(c,:)+tiny*eye(2))*estGam(c,:)'*estpibar(c,1));  
                        ci_all=ci_all+1;
               end
           end  
           
                      l_C_all=length(C_space_all(1,:));
           
           
           
           
           
           
             
           [minob,minindc]=min(obj_all);
        estc=C_space_all(:,minindc); 
        
        
        
      
        
        
        
        store_estc(:,simu)=estc;
        stime_2block(simu)=toc;
        
        if (sum((C_space_all(:,minindc)==(1:2:53)'))==27)
            store_correct(1,simu)=1;
            correct=correct+1;
        end
        
        %store_C_space_all(:,:,simu)=C_space_all;
        %store_obj(:,simu)=obj';
        
   
 obj1=[];
 obj12=[];
 obj123=[];
 obj1234=[];
 obj12345=[];
 obj123456=[];
 obj_all=[];
C_space_all=[];
C_space_estb1=[];
C_space_estb12=[];
C_space_estb123=[];
C_space_estb1234=[];
C_space_estb12345=[];
C_space_estb123456=[];

store_kp(simu,:)=[l_C_estb12 l_C_estb123 l_C_estb1234 l_C_estb12345 l_C_estb123456 l_C_all] ;
end
 time=mean(stime_2block);
 %  mkp=mean(store_kp);
   %correctrate=correct/allsims;
    tab(iall,:)=[alpha1 lambda time correct];     
   iall=iall+1;
              end
          end
          
          truepiA=[theta1A; -delta1A];
        %  mse=sum(mean((store_estpi-truepiA)'.^2));
        %  tab4=[correctrate mse]